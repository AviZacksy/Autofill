# 📋 Booking Auto-Fill Extension - Installation Guide

## 🎯 Overview
This Chrome extension automatically fills booking forms on Forest Rajasthan website with human-like typing simulation.

## 📦 What You'll Get
- **Extension Files**: Complete Chrome extension
- **Sample Excel**: Template with correct format
- **Installation Guide**: This document
- **Video Tutorial**: Step-by-step demonstration

## 🚀 Installation Steps

### Step 1: Download Extension
**Option A: GitHub (Recommended)**
1. Go to: https://github.com/AviZacksy/Autofill.git
2. Click "Code" → "Download ZIP"
3. Extract ZIP to a folder

**Option B: ZIP File**
1. Use the provided `Booking-AutoFill-Extension.zip`
2. Extract to a folder

### Step 2: Load in Chrome
1. Open Chrome browser
2. Type: `chrome://extensions/` in address bar
3. Enable "Developer mode" (top-right toggle)
4. Click "Load unpacked"
5. Select the extension folder
6. Extension will appear in your extensions list

### Step 3: Prepare Excel File
Create Excel file with these columns:

| Column Name | Example | Required |
|-------------|---------|----------|
| Name | Amit Sharma | ✅ |
| Age | 28 | ✅ |
| Gender | male | ✅ |
| TouristType | indian | ✅ |
| IDType | aadhar | ✅ |
| IDValue | 1234-5678-9012 | ✅ |

**Sample Data:**
```
Name: Amit Sharma
Age: 28
Gender: male
TouristType: indian
IDType: aadhar
IDValue: 1234-5678-9012
```

## 🎯 How to Use

### Step 1: Go to Website
1. Visit: https://booking.forestrajasthan.com/
2. Navigate to booking form

### Step 2: Use Extension
1. Click extension icon in Chrome toolbar
2. Upload your Excel file
3. Select user from dropdown
4. Select visitor (1-20)
5. Click "Manual Trigger" or "Start Auto-Fill"

### Step 3: Watch Magic Happen
- Extension will fill form automatically
- Human-like typing simulation
- No bot detection
- Fast and reliable

## ✨ Features

### 🎯 Multiple Visitors Support
- **20 Visitors**: Fill forms for up to 20 visitors
- **Individual Control**: Each visitor separately
- **No Re-filling**: Smart completion tracking

### 🤖 Human-Like Behavior
- **Character-by-Character**: Realistic typing
- **Natural Delays**: Human-like timing
- **Bot Detection Safe**: Undetectable automation

### 📊 Multiple Users
- **Excel Support**: Multiple user records
- **Easy Selection**: Dropdown interface
- **Data Persistence**: Remembers previous data

### ⚡ Performance
- **Fast Filling**: Optimized for speed
- **Reliable**: Error handling
- **Clean Console**: No spam messages

## 🔧 Troubleshooting

### Extension Not Loading?
1. Check Developer mode is ON
2. Verify folder structure is correct
3. Try refreshing extensions page

### Form Not Filling?
1. Check Excel format is correct
2. Ensure you're on correct website
3. Try "Manual Trigger" button

### Fields Not Found?
1. Check if form is fully loaded
2. Verify visitor selection is correct
3. Try refreshing the page

## 📞 Support

### Need Help?
- **GitHub Issues**: Report bugs on GitHub
- **Email Support**: Contact developer
- **Video Tutorial**: Watch demonstration

### Common Issues
1. **Excel Format**: Ensure correct column names
2. **Website Changes**: Extension may need updates
3. **Browser Updates**: Chrome updates may affect extension

## 🎯 Best Practices

### Excel File Tips
- Use exact column names
- Keep data clean and consistent
- Test with sample data first

### Usage Tips
- Start with 1-2 visitors for testing
- Use "Manual Trigger" for better control
- Check console for any errors

### Performance Tips
- Close unnecessary tabs
- Ensure stable internet connection
- Don't interrupt during filling

## 📋 Quick Reference

### Extension Controls
- **Upload Excel**: Select your data file
- **User Selection**: Choose which user data to use
- **Visitor Selection**: Select visitor 1-20
- **Manual Trigger**: Fill current visitor only
- **Start Auto-Fill**: Fill all visitors

### Excel Format
```
Name, Age, Gender, TouristType, IDType, IDValue
Amit Sharma, 28, male, indian, aadhar, 1234-5678-9012
```

### Supported Websites
- ✅ Forest Rajasthan Booking
- ✅ Custom Pages (RTR)
- ✅ Other booking forms

## 🎉 Success Checklist

- [ ] Extension loaded in Chrome
- [ ] Excel file prepared correctly
- [ ] Website opened
- [ ] Form fields visible
- [ ] Extension icon clicked
- [ ] Excel file uploaded
- [ ] User selected
- [ ] Visitor selected
- [ ] Auto-fill triggered
- [ ] Form filled successfully

## 📞 Contact

**Developer**: AviZacksy  
**GitHub**: https://github.com/AviZacksy/Autofill.git  
**Support**: Available on GitHub Issues

---

**Version**: 2.0  
**Last Updated**: December 2024  
**Compatibility**: Chrome 80+ 