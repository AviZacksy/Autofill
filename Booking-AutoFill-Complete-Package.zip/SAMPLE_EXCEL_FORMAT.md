# 📊 Sample Excel Format - Booking Auto-Fill Extension

## 🎯 Required Excel Format

### 📋 Column Headers (Must be exact)
```
Name | Age | Gender | TouristType | IDType | IDValue
```

### 📝 Sample Data

| Name | Age | Gender | TouristType | IDType | IDValue |
|------|-----|--------|-------------|--------|---------|
| Amit Sharma | 28 | male | indian | aadhar | 1234-5678-9012 |
| Priya Singh | 25 | female | indian | pan | ABCDE1234F |
| Rajesh Kumar | 32 | male | indian | passport | A1234567 |
| Meera Patel | 29 | female | indian | driving_license | DL-0120110149646 |
| Suresh Verma | 35 | male | indian | voter_id | ABC1234567 |

## 📋 Detailed Format Guide

### ✅ Correct Format Examples

#### Example 1: Aadhar Card
```
Name: Amit Sharma
Age: 28
Gender: male
TouristType: indian
IDType: aadhar
IDValue: 1234-5678-9012
```

#### Example 2: PAN Card
```
Name: Priya Singh
Age: 25
Gender: female
TouristType: indian
IDType: pan
IDValue: ABCDE1234F
```

#### Example 3: Passport
```
Name: Rajesh Kumar
Age: 32
Gender: male
TouristType: indian
IDType: passport
IDValue: A1234567
```

### ❌ Common Mistakes to Avoid

#### Wrong Column Names
```
❌ Wrong: First Name, Last Name
✅ Correct: Name

❌ Wrong: Age Group
✅ Correct: Age

❌ Wrong: Sex
✅ Correct: Gender

❌ Wrong: Tourist Category
✅ Correct: TouristType

❌ Wrong: ID Proof Type
✅ Correct: IDType

❌ Wrong: ID Number
✅ Correct: IDValue
```

#### Wrong Data Format
```
❌ Wrong: Age: "Twenty Eight"
✅ Correct: Age: 28

❌ Wrong: Gender: "M"
✅ Correct: Gender: male

❌ Wrong: TouristType: "Indian Citizen"
✅ Correct: TouristType: indian

❌ Wrong: IDType: "Aadhar Card"
✅ Correct: IDType: aadhar
```

## 🎯 Supported ID Types

### Valid IDType Values:
- `aadhar` - Aadhar Card
- `pan` - PAN Card
- `passport` - Passport
- `driving_license` - Driving License
- `voter_id` - Voter ID
- `ration_card` - Ration Card

### Valid Gender Values:
- `male`
- `female`
- `other`

### Valid TouristType Values:
- `indian` - Indian Citizen
- `foreigner` - Foreign Tourist
- `nri` - Non-Resident Indian

## 📊 Excel File Creation Steps

### Step 1: Create New Excel File
1. Open Microsoft Excel or Google Sheets
2. Create new workbook

### Step 2: Add Headers
```
Row 1: Name | Age | Gender | TouristType | IDType | IDValue
```

### Step 3: Add Data
```
Row 2: Amit Sharma | 28 | male | indian | aadhar | 1234-5678-9012
Row 3: Priya Singh | 25 | female | indian | pan | ABCDE1234F
Row 4: Rajesh Kumar | 32 | male | indian | passport | A1234567
```

### Step 4: Save File
- Save as `.xlsx` format
- Use descriptive filename like `booking_data.xlsx`

## 🔧 Excel Tips

### Data Validation
- Keep data clean and consistent
- Use proper formatting
- Avoid extra spaces
- Check for typos

### File Size
- Keep file size reasonable
- Remove unnecessary formatting
- Use simple fonts and colors

### Backup
- Keep backup of your data
- Test with sample data first
- Verify data before using

## 📋 Quick Reference

### Required Columns:
1. **Name** - Full name of person
2. **Age** - Numeric age
3. **Gender** - male/female/other
4. **TouristType** - indian/foreigner/nri
5. **IDType** - Type of ID proof
6. **IDValue** - ID number/value

### Sample Row:
```
Amit Sharma | 28 | male | indian | aadhar | 1234-5678-9012
```

### File Format:
- **Extension**: .xlsx
- **Encoding**: UTF-8
- **Headers**: First row
- **Data**: Starting from second row

## 🎯 Testing Your Excel File

### Before Using Extension:
1. ✅ Check all column names are correct
2. ✅ Verify data format is proper
3. ✅ Test with 1-2 rows first
4. ✅ Ensure no extra spaces
5. ✅ Save file properly

### Common Issues:
- Wrong column names
- Extra spaces in data
- Wrong data format
- Missing required columns
- File not saved properly

## 📞 Need Help?

If you have issues with Excel format:
1. Check this guide
2. Use the sample data provided
3. Contact support if needed
4. Test with simple data first

---

**Note**: This format is specifically designed for Forest Rajasthan booking forms. Make sure to use exact column names and data formats for best results. 