// Background script (currently not used)
