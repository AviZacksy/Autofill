// Load saved data if present
chrome.storage.local.get(["bookingData", "lastFileName"], (res) => {
    if (res.bookingData) {
      document.getElementById('status').innerText = "ℹ️ Excel already loaded, ready to use.";
      document.getElementById('status').className = "info";
      document.getElementById('fileName').innerText = `📁 ${res.lastFileName || "File loaded"}`;
      document.getElementById('startBtn').disabled = false;
      document.getElementById('manualBtn').disabled = false;
      
      // Populate user selection dropdown
      populateUserSelection(res.bookingData);
    }
  });
  
  // Check for existing data on page load
  chrome.storage.local.get(['excelData'], (result) => {
    if (result.excelData && result.excelData.length > 0) {
      updateStatus(`✅ Found ${result.excelData.length} records from previous session`, "success");
      document.getElementById('startBtn').disabled = false;
      document.getElementById('manualBtn').disabled = false;
      
      // Show user selection for existing data
      populateUserSelection(result.excelData);
    }
  });
  
  // Excel file upload handler
  document.getElementById('excelFile').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (!file) return;
  
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
  
        if (jsonData.length === 0) {
          updateStatus("❌ No data found in Excel file", "error");
          return;
        }
  
        // Store data and show user selection
        chrome.storage.local.set({ excelData: jsonData }, () => {
          updateStatus(`✅ Loaded ${jsonData.length} records from Excel`, "success");
          document.getElementById('fileName').textContent = file.name;
          document.getElementById('startBtn').disabled = false;
          document.getElementById('manualBtn').disabled = false;
          
          // Show user selection
          populateUserSelection(jsonData);
        });
      } catch (error) {
        updateStatus("❌ Error reading Excel file: " + error.message, "error");
      }
    };
    reader.readAsArrayBuffer(file);
  });
  
  // Function to populate user selection dropdown
  function populateUserSelection(data) {
    const userSelect = document.getElementById('userSelect');
    const userInfo = document.getElementById('userInfo');
    const visitorSelection = document.querySelector('.visitor-selection');
    const visitorSelect = document.getElementById('visitorSelect');
    const visitorInfo = document.getElementById('visitorInfo');
    
    // Clear existing options
    userSelect.innerHTML = '<option value="">Choose a user...</option>';
    
    // Add options for each user
    data.forEach((user, index) => {
      const option = document.createElement('option');
      option.value = index;
      option.textContent = `${index + 1}. ${user.Name || 'Unknown'}`;
      userSelect.appendChild(option);
    });
    
    // Show user selection
    document.querySelector('.user-selection').style.display = 'block';
    visitorSelection.style.display = 'block';
    
    // Add event listener for user selection
    userSelect.addEventListener('change', () => {
      const selectedIndex = parseInt(userSelect.value);
      if (selectedIndex >= 0 && data[selectedIndex]) {
        const user = data[selectedIndex];
        userInfo.innerHTML = `
          <strong>Selected User:</strong><br>
          Name: ${user.Name}<br>
          Age: ${user.Age}<br>
          Gender: ${user.Gender}<br>
          Tourist Type: ${user.TouristType}<br>
          ID Type: ${user.IDType}<br>
          ID Value: ${user.IDValue}
        `;
      }
    });
    
    // Add event listener for visitor selection
    visitorSelect.addEventListener('change', () => {
      const selectedVisitor = parseInt(visitorSelect.value);
      visitorInfo.textContent = `Currently filling: Visitor ${selectedVisitor + 1}`;
    });
    
    // Show first user's info by default
    if (data.length > 0) {
      userInfo.innerHTML = `
        <strong>Selected User:</strong><br>
        Name: ${data[0].Name}<br>
        Age: ${data[0].Age}<br>
        Gender: ${data[0].Gender}<br>
        Tourist Type: ${data[0].TouristType}<br>
        ID Type: ${data[0].IDType}<br>
        ID Value: ${data[0].IDValue}
      `;
    }
  }
  
  // Start button
  document.getElementById('startBtn').addEventListener('click', () => {
    updateStatus("🚀 Starting auto-fill...", "info");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.storage.local.get(["bookingData"], (res) => {
        if (!res.bookingData || res.bookingData.length === 0) {
          updateStatus("❌ No data available. Please upload Excel file first.", "error");
          return;
        }

        const userSelect = document.getElementById('userSelect');
        const visitorSelect = document.getElementById('visitorSelect');
        
        const selectedUserIndex = parseInt(userSelect.value);
        const selectedVisitorIndex = parseInt(visitorSelect.value);
        
        if (selectedUserIndex < 0 || selectedUserIndex >= res.bookingData.length) {
          updateStatus("❌ Please select a valid user from the dropdown.", "error");
          return;
        }
        
        if (selectedVisitorIndex < 0) {
          updateStatus("❌ Please select a valid visitor number.", "error");
          return;
        }

        const selectedData = [res.bookingData[selectedUserIndex]]; // Send only selected user
        const visitorIndex = selectedVisitorIndex; // Send visitor index

        updateStatus("🚀 Sending auto-fill data to content script...", "info");

        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id, allFrames: true },
          func: function(selectedData, visitorIndex) {
            // Disable any existing MutationObserver to prevent infinite spam
            if (window.formObserver) {
              window.formObserver.disconnect();
              console.log("🔒 Existing form observer disabled");
            }
            
            // Disable any other observers
            if (window.observers) {
              window.observers.forEach(observer => observer.disconnect());
              console.log("🔒 All existing observers disabled");
            }
            
            // Disable all MutationObservers globally
            const allObservers = document.querySelectorAll('*');
            allObservers.forEach(element => {
              if (element._mutationObserver) {
                element._mutationObserver.disconnect();
              }
            });
            console.log("🔒 All global observers disabled");
            
            // Reset completion flags
            window.formFillingCompleted = window.formFillingCompleted || {};
            window.lastFormCompletion = window.lastFormCompletion || {};
            
            // Only reset for the current visitor
            const visitorKey = `visitor_${visitorIndex}`;
            delete window.formFillingCompleted[visitorKey];
            delete window.lastFormCompletion[visitorKey];
            
            // Spam prevention - disable console if too many messages
            let messageCount = 0;
            const originalConsoleLog = console.log;
            console.log = function(...args) {
              messageCount++;
              if (messageCount > 50) {
                console.log = function() {}; // Disable console logging
                console.warn("🔇 Console logging disabled due to spam");
                return;
              }
              originalConsoleLog.apply(console, args);
            };

            console.log("🚀 Sending auto-fill data to content script...");
            window.postMessage({ type: "AUTO_FILL", payload: data, visitorIndex: visitorIndex }, "*");
          },
          args: [selectedData, visitorIndex]
        });
      });
    });
  });

  // Manual trigger button
  document.getElementById('manualBtn').addEventListener('click', () => {
    updateStatus("🔧 Manual trigger activated...", "info");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.storage.local.get(["bookingData"], (res) => {
        if (!res.bookingData || res.bookingData.length === 0) {
          updateStatus("❌ No data available. Please upload Excel file first.", "error");
          return;
        }

        const userSelect = document.getElementById('userSelect');
        const visitorSelect = document.getElementById('visitorSelect');
        
        const selectedUserIndex = parseInt(userSelect.value);
        const selectedVisitorIndex = parseInt(visitorSelect.value);
        
        if (selectedUserIndex < 0 || selectedUserIndex >= res.bookingData.length) {
          updateStatus("❌ Please select a valid user from the dropdown.", "error");
          return;
        }
        
        if (selectedVisitorIndex < 0) {
          updateStatus("❌ Please select a valid visitor number.", "error");
          return;
        }

        const selectedData = [res.bookingData[selectedUserIndex]]; // Send only selected user
        const visitorIndex = selectedVisitorIndex; // Send visitor index

        updateStatus("🚀 Sending auto-fill data to content script...", "info");
  
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id, allFrames: true },
          func: (data, visitorIndex) => {
            console.log("🔧 Manual trigger: Analyzing page for form fields...");
            console.log("👤 Selected visitor index:", visitorIndex);
            
            // Aggressive security script suppression
            try {
              // Override global error handler
              window.addEventListener('error', function(e) {
                if (e.filename && e.filename.includes('security.js')) {
                  e.preventDefault();
                  e.stopPropagation();
                  return false;
                }
              }, true);
              
              // Override unhandledrejection
              window.addEventListener('unhandledrejection', function(e) {
                if (e.reason && e.reason.toString().includes('security.js')) {
                  e.preventDefault();
                  return false;
                }
              });
              
              // Override console.error to suppress security.js errors
              const originalConsoleError = console.error;
              console.error = function(...args) {
                const message = args.join(' ');
                if (message.includes('security.js') || 
                    message.includes('toLowerCase') || 
                    message.includes('Cannot read properties')) {
                  return; // Suppress security.js errors completely
                }
                originalConsoleError.apply(console, args);
              };
              
              // Override console.warn to suppress security.js warnings
              const originalConsoleWarn = console.warn;
              console.warn = function(...args) {
                const message = args.join(' ');
                if (message.includes('security.js') || 
                    message.includes('toLowerCase') || 
                    message.includes('Cannot read properties')) {
                  return; // Suppress security.js warnings completely
                }
                originalConsoleWarn.apply(console, args);
              };
              
              // Block security.js script execution
              const originalCreateElement = document.createElement;
              document.createElement = function(tagName) {
                const element = originalCreateElement.call(document, tagName);
                if (tagName.toLowerCase() === 'script') {
                  const originalSetAttribute = element.setAttribute;
                  element.setAttribute = function(name, value) {
                    if (name === 'src' && value.includes('security.js')) {
                      return; // Block security.js script loading
                    }
                    originalSetAttribute.call(this, name, value);
                  };
                }
                return element;
              };
              
            } catch (e) {
              console.log("🔒 Security suppression setup completed");
            }
            
            // Human-like typing function
            async function humanType(element, text) {
              try {
                console.log(`📝 Human typing '${text}' into ${element.tagName}`);
                
                // Focus the element first
                element.focus();
                element.click();
                
                // Wait before starting to type (human-like delay)
                await new Promise(r => setTimeout(r, 200 + Math.random() * 300));
                
                // Clear existing value
                element.value = "";
                
                // Type character by character with human-like delays
                const textToType = String(text).trim();
                for (let i = 0; i < textToType.length; i++) {
                  const char = textToType[i];
                  
                  // Add character
                  element.value += char;
                  
                  // Dispatch input event for each character
                  try {
                    element.dispatchEvent(new Event("input", { bubbles: true }));
                  } catch (e) {
                    // Ignore security script errors
                  }
                  
                  // Human-like delay between characters (80-150ms)
                  await new Promise(r => setTimeout(r, 80 + Math.random() * 70));
                  
                  // Occasionally add a longer pause (like human thinking)
                  if (Math.random() < 0.1) {
                    await new Promise(r => setTimeout(r, 200 + Math.random() * 300));
                  }
                }
                
                // Wait after typing is complete
                await new Promise(r => setTimeout(r, 150 + Math.random() * 200));
                
                // Dispatch final events
                try {
                  element.dispatchEvent(new Event("change", { bubbles: true }));
                  element.dispatchEvent(new Event("blur", { bubbles: true }));
                } catch (e) {
                  // Ignore security script errors
                }
                
                // Check if value was set correctly
                const expectedValue = String(text).trim();
                const actualValue = element.value;
                
                if (element.name && element.name.includes('name')) {
                  // For name fields, check case-insensitive
                  if (actualValue.toLowerCase() !== expectedValue.toLowerCase()) {
                    console.log(`⚠️ Name field case mismatch: expected "${expectedValue}", got "${actualValue}"`);
                  } else {
                    console.log(`✅ Human typed: ${element.tagName} = "${actualValue}"`);
                  }
                } else {
                  // For other fields, check exact match
                  if (actualValue !== expectedValue) {
                    console.log(`⚠️ Field value mismatch: expected "${expectedValue}", got "${actualValue}"`);
                  } else {
                    console.log(`✅ Human typed: ${element.tagName} = "${actualValue}"`);
                  }
                }
              } catch (err) {
                console.warn(`❌ Typing failed for ${element.tagName}`, err);
              }
            }

            // Human-like dropdown selection function
            async function humanSelectDropdown(element, value) {
              console.log(`🔽 Human selecting '${value}' in ${element.tagName}`);
              
              try {
                // Focus and click to open dropdown (human-like)
                element.focus();
                element.click();
                
                // Wait for dropdown to open (human-like delay)
                await new Promise(r => setTimeout(r, 150 + Math.random() * 200));
                
                const val = String(value).trim().toLowerCase();
                
                // Try exact match first
                for (let opt of element.options) {
                  if (opt.value.toLowerCase() === val || opt.text.toLowerCase() === val) {
                    // Simulate human selection with delays
                    element.focus();
                    
                    // Wait before selecting (human-like)
                    await new Promise(r => setTimeout(r, 100 + Math.random() * 150));
                    
                    element.value = opt.value;
                    
                    try {
                      element.dispatchEvent(new Event("change", { bubbles: true }));
                      element.dispatchEvent(new Event("input", { bubbles: true }));
                    } catch (e) {
                      console.log("🔒 Security script detected on dropdown change");
                    }
                    
                    // Wait after selection (human-like)
                    await new Promise(r => setTimeout(r, 100 + Math.random() * 150));
                    
                    console.log(`✅ Human selected: ${opt.text} in ${element.tagName}`);
                    return;
                  }
                }
                
                // Try partial match
                for (let opt of element.options) {
                  if (opt.value.toLowerCase().includes(val) || opt.text.toLowerCase().includes(val)) {
                    // Simulate human selection with delays
                    element.focus();
                    
                    // Wait before selecting (human-like)
                    await new Promise(r => setTimeout(r, 100 + Math.random() * 150));
                    
                    element.value = opt.value;
                    
                    try {
                      element.dispatchEvent(new Event("change", { bubbles: true }));
                      element.dispatchEvent(new Event("input", { bubbles: true }));
                    } catch (e) {
                      console.log("🔒 Security script detected on dropdown change");
                    }
                    
                    // Wait after selection (human-like)
                    await new Promise(r => setTimeout(r, 100 + Math.random() * 150));
                    
                    console.log(`✅ Human selected (partial): ${opt.text} in ${element.tagName}`);
                    return;
                  }
                }
                
                console.warn(`❌ Value '${value}' not found in ${element.tagName}. Available options:`, 
                  Array.from(element.options).map(opt => `${opt.value} (${opt.text})`));
              } catch (err) {
                console.warn(`❌ Dropdown selection failed for ${element.tagName}`, err);
              }
            }
            
            // Function to analyze current page
            async function analyzePage() {
              // Ensure visitorIndex is properly set
              if (typeof visitorIndex === 'undefined' || visitorIndex === null) {
                visitorIndex = 0; // Default to visitor 0
                console.log("⚠️ Visitor index not set, defaulting to visitor 0");
              }
              
              // Check if form filling is already completed for this specific visitor
              const visitorKey = `visitor_${visitorIndex}`;
              if (window.formFillingCompleted && window.formFillingCompleted[visitorKey]) {
                console.log(`✅ Form filling already completed for visitor ${visitorIndex + 1}, skipping...`);
                return;
              }
              
              const inputs = document.querySelectorAll('input, select, textarea');
              console.log("🔍 Found", inputs.length, "form elements on", window.location.href);
              
              if (inputs.length === 0) {
                console.log("❌ No form fields found on this page");
                return;
              }
              
              // Check if already completed recently for this visitor
              const now = Date.now();
              const lastCompletion = window.lastFormCompletion && window.lastFormCompletion[visitorKey] || 0;
              if (now - lastCompletion < 30000) { // 30 seconds
                console.log(`✅ Visitor ${visitorIndex + 1} already completed recently, skipping...`);
                return;
              }
              
              // Log all form elements
              inputs.forEach((input, index) => {
                const type = input.type || input.tagName.toLowerCase();
                const name = input.name || '';
                const id = input.id || '';
                const placeholder = input.placeholder || '';
                console.log(`${index + 1}. ${type} - name:"${name}" id:"${id}" placeholder:"${placeholder}"`);
              });
              
              // Try to fill if we find any fields
              if (inputs.length > 0) {
                console.log("✅ Found form fields, attempting to fill...");
                
                const record = data[0];
                if (!record) {
                  console.error("❌ No data available");
                  return;
                }
                
                console.log(`👤 Filling Visitor ${visitorIndex + 1} with data:`, record);
                
                // Mark completion timestamp for this specific visitor
                window.lastFormCompletion = window.lastFormCompletion || {};
                window.lastFormCompletion[`visitor_${visitorIndex}`] = Date.now();
                
                // Fill fields one by one with proper delays
                const fieldsToFill = [
                  {
                    name: 'name',
                    value: record.Name,
                    selectors: [
                      `input[name="data[dataGrid1][${visitorIndex}][name]"]`,
                      `input[name*="[${visitorIndex}][name]"]`,
                      'input[name*="name" i]',
                      'input[placeholder*="name" i]',
                      'input[id*="name" i]',
                      'input[type="text"]'
                    ]
                  },
                  {
                    name: 'age',
                    value: record.Age,
                    selectors: [
                      `input[name="data[dataGrid1][${visitorIndex}][age]"]`,
                      `input[name*="[${visitorIndex}][age]"]`,
                      'input[name*="age" i]',
                      'input[placeholder*="age" i]',
                      'input[id*="age" i]',
                      'input[type="number"]'
                    ]
                  },
                  {
                    name: 'gender',
                    value: record.Gender,
                    selectors: [
                      `select[name="data[dataGrid1][${visitorIndex}][gender]"]`,
                      `select[name*="[${visitorIndex}][gender]"]`,
                      'select[name*="gender" i]',
                      'select[id*="gender" i]',
                      'select'
                    ],
                    isDropdown: true
                  },
                  {
                    name: 'touristType',
                    value: record.TouristType,
                    selectors: [
                      `select[name="data[dataGrid1][${visitorIndex}][touristType]"]`,
                      `select[name*="[${visitorIndex}][touristType]"]`,
                      'select[name*="touristType" i]',
                      'select[id*="touristType" i]',
                      'select[name="data[dataGrid1][0][touristType]"]'
                    ],
                    isDropdown: true
                  },
                  {
                    name: 'idType',
                    value: record.IDType,
                    selectors: [
                      `select[name="data[dataGrid1][${visitorIndex}][idType]"]`,
                      `select[name*="[${visitorIndex}][idType]"]`,
                      'select[name*="idType" i]',
                      'select[id*="idType" i]',
                      'select[name="data[dataGrid1][0][idType]"]'
                    ],
                    isDropdown: true
                  },
                  {
                    name: 'idValue',
                    value: record.IDValue,
                    selectors: [
                      `input[name="data[dataGrid1][${visitorIndex}][idValue]"]`,
                      `input[name*="[${visitorIndex}][idValue]"]`,
                      'input[name*="idValue" i]',
                      'input[id*="idValue" i]',
                      'input[placeholder*="ID Proof" i]',
                      'input[name="data[dataGrid1][0][idValue]"]'
                    ]
                  }
                ];
                
                // Fill each field with proper delays
                for (let field of fieldsToFill) {
                  if (!field.value) continue;
                  
                  let fieldElement = null;
                  for (let selector of field.selectors) {
                    fieldElement = document.querySelector(selector);
                    if (fieldElement) break;
                  }
                  
                  if (fieldElement) {
                    console.log(`📝 Filling ${field.name}: ${field.value}`);
                    
                    if (field.isDropdown) {
                      await humanSelectDropdown(fieldElement, field.value);
                    } else {
                      await humanType(fieldElement, field.value);
                    }
                    
                    // Wait between fields (reduced delay for faster filling)
                    await new Promise(r => setTimeout(r, 200 + Math.random() * 200));
                    
                    // Simple verification - reduced spam
                    if (fieldElement.value !== field.value && !field.isDropdown) {
                      // Only log if there's a real mismatch (not just case difference for names)
                      if (field.name && field.name.includes('name')) {
                        if (fieldElement.value.toLowerCase() !== field.value.toLowerCase()) {
                          console.log(`⚠️ Name field case mismatch: expected "${field.value}", got "${fieldElement.value}"`);
                        }
                      } else {
                        console.log(`⚠️ Field ${field.name} value mismatch: expected "${field.value}", got "${fieldElement.value}"`);
                      }
                    }
                  }
                }
                
                console.log("✅ Manual fill completed!");
                
                // Disable dynamic form detection to prevent re-filling
                window.formFillingCompleted = window.formFillingCompleted || {};
                window.formFillingCompleted[`visitor_${visitorIndex}`] = true;
                
                // Disable MutationObserver if it exists
                if (window.formObserver) {
                  window.formObserver.disconnect();
                  console.log("🔒 Dynamic form detection disabled");
                }
                
                // Also disable any other observers
                if (window.observers) {
                  window.observers.forEach(observer => observer.disconnect());
                  console.log("🔒 All observers disabled");
                }
                
                // Show success banner
                const banner = document.createElement('div');
                banner.innerHTML = `✅ Visitor ${visitorIndex + 1} filled successfully!`;
                banner.style.cssText = 'position: fixed; top: 10px; right: 10px; background: green; color: white; padding: 10px; border-radius: 5px; z-index: 99999;';
                document.body.appendChild(banner);
                setTimeout(() => banner.remove(), 3000);
              }
            }
            
            // Start the analysis
            analyzePage();
            
            // DISABLED: MutationObserver causing infinite spam
            /*
            // Set up mutation observer for dynamic form fields
            const observer = new MutationObserver((mutations) => {
              mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                  const newInputs = document.querySelectorAll('input, select, textarea');
                  if (newInputs.length > 0) {
                    console.log("🎯 New form fields detected dynamically!");
                    analyzePage();
                  }
                }
              });
            });
            
            observer.observe(document.body, { childList: true, subtree: true });
            
            // Stop observing after 30 seconds
            setTimeout(() => {
              observer.disconnect();
              console.log("⏰ Dynamic field detection stopped");
            }, 30000);
            */
            
          },
          args: [selectedData, visitorIndex]
        });
      });
    });
  });
  
  function updateStatus(message, type) {
    const el = document.getElementById('status');
    el.innerText = message;
    el.className = type;
  }